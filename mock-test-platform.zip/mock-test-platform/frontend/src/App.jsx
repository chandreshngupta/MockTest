import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import TestPage from './pages/TestPage';
import TestList from './components/TestList';

const App = () => {
    return (
        <Router>
            <div>
                <h1>Mock Test Platform</h1>
                <Switch>
                    <Route path="/" exact component={Dashboard} />
                    <Route path="/tests" component={TestList} />
                    <Route path="/test/:id" component={TestPage} />
                </Switch>
            </div>
        </Router>
    );
};

export default App;