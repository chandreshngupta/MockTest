import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
    return (
        <div className="dashboard">
            <h1>Dashboard</h1>
            <p>Welcome to the Mock Test Platform!</p>
            <h2>Available Tests</h2>
            <ul>
                <li><Link to="/test/1">Test 1</Link></li>
                <li><Link to="/test/2">Test 2</Link></li>
                <li><Link to="/test/3">Test 3</Link></li>
            </ul>
            <h2>User Statistics</h2>
            <p>Tests Taken: 5</p>
            <p>Average Score: 85%</p>
        </div>
    );
};

export default Dashboard;