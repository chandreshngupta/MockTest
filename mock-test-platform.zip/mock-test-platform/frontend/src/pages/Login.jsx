import { useState } from "react";
import axios from "axios";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    const res = await axios.post("http://localhost:8000/auth/login", null, {
      params: { email, password }
    });
    localStorage.setItem("token", res.data.access_token);
    alert("Login successful");
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 shadow-lg rounded-xl w-80">
        <h2 className="text-xl font-bold mb-4 text-center">Login</h2>
        <input className="border p-2 mb-3 w-full" placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
        <input className="border p-2 mb-3 w-full" placeholder="Password" type="password" onChange={(e) => setPassword(e.target.value)} />
        <button onClick={handleLogin} className="bg-blue-500 text-white px-4 py-2 w-full rounded">Login</button>
      </div>
    </div>
  );
}
