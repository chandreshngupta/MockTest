import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import QuestionCard from "../components/QuestionCard";
import AnalyticsChart from "../components/AnalyticsChart";

export default function TestPage({ match, user }) {
  // match.params.testId if using react-router v5; adapt to your router.
  const testId = match?.params?.testId || new URLSearchParams(window.location.search).get("test_id");
  const [test, setTest] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({}); // {qid: {answer, time_spent}}
  const [timeLeft, setTimeLeft] = useState(null); // seconds
  const [started, setStarted] = useState(false);
  const [responseId, setResponseId] = useState(null);
  const [result, setResult] = useState(null);
  const timerRef = useRef(null);
  const questionStartAt = useRef(Date.now());

  useEffect(() => {
    fetchTest();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const fetchTest = async () => {
    const res = await axios.get(`http://localhost:8000/tests/${testId}`);
    setTest({
      id: res.data.id,
      title: res.data.title,
      subject: res.data.subject,
      duration: res.data.duration
    });
    setQuestions(res.data.questions);
    setTimeLeft(res.data.duration * 60);
  };

  const startTest = async () => {
    // create a response row
    const res = await axios.post("http://localhost:8000/responses/start", {
      user_id: user.id,
      test_id: testId
    });
    setResponseId(res.data.response_id);
    setStarted(true);
    questionStartAt.current = Date.now();
    startTimer();
    // start autosave interval
    autosaveInterval();
  };

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev === null) return prev;
        if (prev <= 1) {
          clearInterval(timerRef.current);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const pauseTimer = () => {
    clearInterval(timerRef.current);
  };

  const resumeTimer = () => {
    startTimer();
  };

  const handleAnswerChange = (qid, val) => {
    // compute time spent since questionStartAt
    const now = Date.now();
    const elapsed = Math.floor((now - questionStartAt.current) / 1000);
    const prev = answers[qid] || {};
    setAnswers(prevState => ({
      ...prevState,
      [qid]: { answer: val, time_spent: (prev.time_spent || 0) + elapsed }
    }));
    questionStartAt.current = Date.now();
  };

  const goTo = (idx) => {
    // accumulate time spent on current question before switching
    const now = Date.now();
    const elapsed = Math.floor((now - questionStartAt.current) / 1000);
    const currentQ = questions[current];
    if (currentQ) {
      setAnswers(prevState => {
        const qid = String(currentQ.id);
        const prev = prevState[qid] || {};
        return {
          ...prevState,
          [qid]: {
            answer: prev.answer,
            time_spent: (prev.time_spent || 0) + elapsed
          }
        };
      });
    }
    questionStartAt.current = Date.now();
    setCurrent(idx);
  };

  const autosave = async () => {
    if (!responseId) return;
    // prepare payload: restructure to API expected shape: {qid: {answer, time_spent}}
    const payloadAnswers = {};
    for (const [qid, val] of Object.entries(answers)) {
      payloadAnswers[qid] = val;
    }
    await axios.post("http://localhost:8000/responses/autosave", {
      response_id: responseId,
      answers: payloadAnswers
    }).catch(e => console.error("autosave error", e));
    // optionally show tiny toast
  };

  // autosave every 10s
  const autosaveInterval = () => {
    setInterval(() => {
      autosave();
    }, 10000);
  };

  const handleSubmit = async () => {
    // finalize time for current question
    const now = Date.now();
    const elapsed = Math.floor((now - questionStartAt.current) / 1000);
    const currentQ = questions[current];
    if (currentQ) {
      setAnswers(prevState => {
        const qid = String(currentQ.id);
        const prev = prevState[qid] || {};
        return {
          ...prevState,
          [qid]: {
            answer: prev.answer,
            time_spent: (prev.time_spent || 0) + elapsed
          }
        };
      });
    }
    pauseTimer();
    // confirmation
    if (!window.confirm("Are you sure you want to submit the test?")) {
      resumeTimer();
      return;
    }
    // send submit
    const payloadAnswers = {};
    for (const [qid, val] of Object.entries(answers)) payloadAnswers[qid] = val;
    const res = await axios.post("http://localhost:8000/responses/submit", {
      response_id: responseId,
      user_id: user.id,
      test_id: testId,
      answers: payloadAnswers
    });
    setResult(res.data);
    // show analytics
  };

  if (!test) return <div className="p-6">Loading test...</div>;
  if (!started) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold">{test.title}</h1>
        <p className="text-gray-600">{test.subject} — Duration: {test.duration} min</p>
        <button onClick={startTest} className="mt-4 bg-blue-600 px-4 py-2 text-white rounded">Start Test</button>
      </div>
    );
  }

  if (result) {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold">Your Result</h2>
        <div className="mt-4">
          <p>Score: {result.score}</p>
          <p>Accuracy: {result.accuracy.toFixed(2)}%</p>
          <p>Avg time/question: {result.avg_time_per_question ? result.avg_time_per_question.toFixed(2)+"s": "N/A"}</p>
        </div>
        <div className="mt-6">
          <AnalyticsChart detail={result.detail} answers={answers} questions={questions} />
        </div>
      </div>
    );
  }

  const q = questions[current];
  const qAnswer = answers[String(q?.id)]?.answer || null;

  return (
    <div className="p-6 grid grid-cols-12 gap-4">
      <div className="col-span-9">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">{test.title}</h2>
          <div>
            <span className="mr-4">Time left: {Math.floor(timeLeft/60)}:{String(timeLeft%60).padStart(2,"0")}</span>
            <button onClick={() => { pauseTimer(); }} className="px-2 py-1 border rounded mr-2">Pause</button>
            <button onClick={() => { resumeTimer(); }} className="px-2 py-1 border rounded">Resume</button>
          </div>
        </div>

        <QuestionCard q={q} value={qAnswer} onChange={(qid, val)=> {
          handleAnswerChange(String(qid), val);
        }} />

        <div className="flex justify-between items-center">
          <div>
            <button disabled={current===0} onClick={() => goTo(current-1)} className="px-3 py-1 border rounded mr-2">Previous</button>
            <button disabled={current===questions.length-1} onClick={() => goTo(current+1)} className="px-3 py-1 border rounded">Next</button>
          </div>
          <div>
            <button onClick={autosave} className="px-3 py-1 border rounded mr-2">Save</button>
            <button onClick={handleSubmit} className="px-3 py-1 bg-red-600 text-white rounded">Submit</button>
          </div>
        </div>
      </div>

      <aside className="col-span-3">
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-2">Question Navigator</h3>
          <div className="grid grid-cols-5 gap-2">
            {questions.map((qq, idx) => {
              const answered = !!answers[String(qq.id)]?.answer;
              return (
                <button key={qq.id} onClick={()=>goTo(idx)} className={`p-2 rounded ${idx===current ? "bg-blue-200": "bg-gray-100"}`}>
                  <div className="text-sm">{idx+1}</div>
                  <div className="text-xs">{answered ? "✓" : ""}</div>
                </button>
              );
            })}
          </div>
        </div>
      </aside>
    </div>
  );
}
