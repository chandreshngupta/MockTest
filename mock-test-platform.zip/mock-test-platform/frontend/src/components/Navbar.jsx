import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TestList = () => {
    const [tests, setTests] = useState([]);

    useEffect(() => {
        const fetchTests = async () => {
            try {
                const response = await axios.get('/api/tests');
                setTests(response.data);
            } catch (error) {
                console.error('Error fetching tests:', error);
            }
        };

        fetchTests();
    }, []);

    return (
        <div>
            <h2>Available Tests</h2>
            <ul>
                {tests.map(test => (
                    <li key={test.id}>
                        {test.title}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default TestList;