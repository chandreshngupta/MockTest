import React from "react";

export default function QuestionCard({ q, value, onChange }) {
  // q: {id, type, question_text, options, marks}
  const id = q.id;
  const handleChange = (v) => {
    onChange(id, v);
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow mb-4">
      <div className="mb-2 text-sm text-gray-500">Marks: {q.marks}</div>
      <div className="mb-4 text-lg font-medium">{q.question_text}</div>

      {q.type === "mcq" && q.options && (
        <div className="space-y-2">
          {q.options.map((opt) => (
            <label key={opt.id} className="block p-2 border rounded hover:bg-gray-50">
              <input
                type="radio"
                name={`q-${id}`}
                value={opt.id}
                checked={value === opt.id}
                onChange={() => handleChange(opt.id)}
                className="mr-2"
              />
              <span>{opt.text}</span>
            </label>
          ))}
        </div>
      )}

      {q.type === "truefalse" && (
        <div className="space-x-4">
          <button className={`px-3 py-1 border rounded ${value === "true" ? "bg-blue-100" : ""}`} onClick={() => handleChange("true")}>True</button>
          <button className={`px-3 py-1 border rounded ${value === "false" ? "bg-blue-100" : ""}`} onClick={() => handleChange("false")}>False</button>
        </div>
      )}

      {(q.type === "fillblank" || q.type === "short") && (
        <div>
          <input
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            className="w-full border p-2 rounded"
            placeholder="Type your answer..."
          />
        </div>
      )}
    </div>
  );
}
