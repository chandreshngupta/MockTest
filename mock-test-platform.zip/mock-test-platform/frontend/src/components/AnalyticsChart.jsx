import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, Legend } from "recharts";

export default function AnalyticsChart({ detail, answers, questions }) {
  // detail: {qid: {"correct": Bool, "marks":n}}
  const barData = Object.entries(detail).map(([qid, info]) => {
    const q = questions.find(x => x.id === parseInt(qid)) || {};
    return {
      name: `Q${qid}`,
      marks: info.marks || 0
    };
  });

  const correctCount = Object.values(detail).filter(d => d.marks > 0).length;
  const incorrectCount = Object.keys(detail).length - correctCount;

  const pieData = [
    { name: 'Correct', value: correctCount },
    { name: 'Incorrect', value: incorrectCount }
  ];

  const COLORS = ["#0088FE", "#FF8042"];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-white p-4 rounded shadow">
        <h4 className="font-semibold mb-2">Marks per question</h4>
        <BarChart width={400} height={250} data={barData}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="marks" />
        </BarChart>
      </div>

      <div className="bg-white p-4 rounded shadow">
        <h4 className="font-semibold mb-2">Correct vs Incorrect</h4>
        <PieChart width={300} height={250}>
          <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
            {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
          </Pie>
          <Legend />
        </PieChart>
      </div>
    </div>
  );
}
