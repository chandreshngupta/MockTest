from sqlalchemy import Column, Integer, String, Text, ForeignKey, TIMESTAMP
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import JSONB
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(Text, nullable=False)
    role = Column(String(20), default="user")
    created_at = Column(TIMESTAMP, server_default=func.now())

class Test(Base):
    __tablename__ = "tests"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(150))
    subject = Column(String(100))
    duration = Column(Integer)  # duration in minutes
    created_at = Column(TIMESTAMP, server_default=func.now())

class Question(Base):
    __tablename__ = "questions"
    id = Column(Integer, primary_key=True, index=True)
    test_id = Column(Integer, ForeignKey("tests.id", ondelete="CASCADE"))
    type = Column(String(50))  # 'mcq', 'truefalse', 'fillblank', 'short'
    section = Column(String(100), nullable=True)
    question_text = Column(Text)
    options = Column(JSONB)   # for mcq: [{"id":"A","text":"..."}]
    correct_answer = Column(Text)  # store canonical correct answer or JSON for multiple-correct
    marks = Column(Integer, default=1)

class Response(Base):
    __tablename__ = "responses"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    test_id = Column(Integer, ForeignKey("tests.id"))
    answers = Column(JSONB, default={})   # {question_id: {answer:..., time_spent: ...}}
    score = Column(Integer, default=0)
    start_time = Column(TIMESTAMP, nullable=True)
    pause_events = Column(JSONB, default=[])  # list of {"pause_at": ts, "resume_at": ts}
    submitted_at = Column(TIMESTAMP, nullable=True)
