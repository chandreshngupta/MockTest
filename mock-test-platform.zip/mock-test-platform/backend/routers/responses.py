from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, database
from pydantic import BaseModel
from typing import Dict, Any, Optional
from datetime import datetime
import json

router = APIRouter(prefix="/responses", tags=["responses"])

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

# helper scoring function
def compute_score(db: Session, test_id: int, answers: Dict[str, Any]):
    """
    answers: {question_id: {"answer": "...", "time_spent": n}}
    """
    total_score = 0
    detail = {}
    for qid_str, payload in answers.items():
        try:
            qid = int(qid_str)
        except:
            continue
        q = db.query(models.Question).filter(models.Question.id == qid, models.Question.test_id == test_id).first()
        if not q:
            continue
        correct = False
        user_ans = payload.get("answer")
        # scoring per type
        if q.type in ("mcq", "truefalse"):
            # options/correct stored as simple string or JSON
            correct_ans = (q.correct_answer or "").strip().lower()
            if isinstance(user_ans, str):
                if user_ans.strip().lower() == correct_ans:
                    correct = True
        else:
            # fill-in / short answer: simple normalization (case-insensitive exact match)
            correct_ans = (q.correct_answer or "").strip().lower()
            if isinstance(user_ans, str) and user_ans.strip().lower() == correct_ans:
                correct = True
        if correct:
            total_score += q.marks or 1
            detail[qid] = {"correct": True, "marks": q.marks}
        else:
            detail[qid] = {"correct": False, "marks": 0}
    return total_score, detail

# Start test (creates a response row if not exists)
class StartPayload(BaseModel):
    user_id: int
    test_id: int

@router.post("/start")
def start_test(payload: StartPayload, db: Session = Depends(get_db)):
    resp = db.query(models.Response).filter(models.Response.user_id == payload.user_id, models.Response.test_id == payload.test_id).first()
    if not resp:
        resp = models.Response(user_id=payload.user_id, test_id=payload.test_id, start_time=datetime.utcnow(), answers={})
        db.add(resp)
        db.commit()
        db.refresh(resp)
    else:
        # update start_time if not set
        if not resp.start_time:
            resp.start_time = datetime.utcnow()
            db.commit()
    return {"response_id": resp.id, "started_at": resp.start_time.isoformat()}

# Autosave
class AutoSavePayload(BaseModel):
    response_id: int
    answers: Dict[str, Any]  # sample: {"12": {"answer":"A", "time_spent": 15}, ...}
    last_action_ts: Optional[str] = None  # optional string timestamp

@router.post("/autosave")
def autosave(payload: AutoSavePayload, db: Session = Depends(get_db)):
    resp = db.query(models.Response).filter(models.Response.id == payload.response_id).first()
    if not resp:
        raise HTTPException(404, "Response not found")
    # merge answers
    existing = resp.answers or {}
    existing.update(payload.answers)
    resp.answers = existing
    db.commit()
    return {"message": "saved", "response_id": resp.id}

# Submit and score
class SubmitPayload(BaseModel):
    response_id: int
    user_id: int
    test_id: int
    answers: Dict[str, Any]

@router.post("/submit")
def submit_test(payload: SubmitPayload, db: Session = Depends(get_db)):
    resp = db.query(models.Response).filter(models.Response.id == payload.response_id).first()
    if not resp:
        raise HTTPException(404, "Response not found")
    # ensure we save final answers
    existing = resp.answers or {}
    existing.update(payload.answers)
    resp.answers = existing
    total_score, detail = compute_score(db, payload.test_id, resp.answers)
    resp.score = total_score
    resp.submitted_at = datetime.utcnow()
    db.commit()
    # analytics: compute accuracy, time per question if available
    total_questions = len(resp.answers.keys())
    correct_count = sum(1 for v in detail.values() if v["marks"]>0)
    accuracy = (correct_count / (total_questions or 1)) * 100
    # compute avg time
    times = []
    for qid, a in resp.answers.items():
        t = a.get("time_spent")
        if isinstance(t, (int, float)):
            times.append(float(t))
    avg_time = sum(times)/len(times) if times else None

    return {
        "response_id": resp.id,
        "score": total_score,
        "accuracy": accuracy,
        "total_questions": total_questions,
        "correct_count": correct_count,
        "avg_time_per_question": avg_time,
        "detail": detail
    }

@router.get("/{response_id}/result")
def get_result(response_id: int, db: Session = Depends(get_db)):
    resp = db.query(models.Response).filter(models.Response.id == response_id).first()
    if not resp:
        raise HTTPException(404, "Response not found")
    return {
        "response_id": resp.id,
        "user_id": resp.user_id,
        "test_id": resp.test_id,
        "answers": resp.answers,
        "score": resp.score,
        "start_time": resp.start_time,
        "pause_events": resp.pause_events,
        "submitted_at": resp.submitted_at
    }
