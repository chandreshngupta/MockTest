from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, database
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/tests", tags=["tests"])

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

class TestOut(BaseModel):
    id: int
    title: str
    subject: str
    duration: int
    class Config:
        orm_mode = True

@router.get("/", response_model=List[TestOut])
def list_tests(db: Session = Depends(get_db)):
    return db.query(models.Test).all()

@router.get("/{test_id}")
def get_test(test_id: int, db: Session = Depends(get_db)):
    test = db.query(models.Test).filter(models.Test.id == test_id).first()
    if not test:
        raise HTTPException(404, "Test not found")
    questions = db.query(models.Question).filter(models.Question.test_id == test_id).all()
    # return test metadata + questions (we DO NOT send correct_answer to clients)
    q_list = []
    for q in questions:
        q_list.append({
            "id": q.id,
            "type": q.type,
            "section": q.section,
            "question_text": q.question_text,
            "options": q.options,
            "marks": q.marks
        })
    return {
        "id": test.id,
        "title": test.title,
        "subject": test.subject,
        "duration": test.duration,
        "questions": q_list
    }
