from fastapi import FastAPI
from . import models
from .database import engine
from .routers import auth, tests, responses
from fastapi.middleware.cors import CORSMiddleware

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Mock Test Platform API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # later restrict to your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(tests.router)
app.include_router(responses.router)

@app.get("/")
def root():
    return {"message": "Mock Test Platform API is running"}
