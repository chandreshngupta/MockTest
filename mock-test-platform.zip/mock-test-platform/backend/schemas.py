from pydantic import BaseModel
from typing import List, Optional

class QuestionSchema(BaseModel):
    id: int
    question_text: str
    options: List[str]
    correct_answer: str

class TestSchema(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    questions: List[QuestionSchema]

class UserSchema(BaseModel):
    id: int
    username: str
    email: str

class AuthResponseSchema(BaseModel):
    access_token: str
    token_type: str
    user: UserSchema