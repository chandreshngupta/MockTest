# Mock Test Platform

## Overview
The Mock Test Platform is a web application designed to facilitate the creation, management, and execution of mock tests. It consists of a backend built with Python and FastAPI, and a frontend developed using React.

## Project Structure
The project is organized into two main directories: `backend` and `frontend`.

### Backend
- **app**: Contains the main application code.
  - `__init__.py`: Initializes the app package.
  - `main.py`: Entry point of the backend application.
  - `config.py`: Configuration settings for the application.
  - `models.py`: Data models used in the application.
  - `schemas.py`: Pydantic schemas for data validation and serialization.
  - **routes**: Contains route definitions.
    - `auth.py`: User authentication routes.
    - `tests.py`: Routes for managing tests.
  - **services**: Contains business logic.
    - `grading.py`: Functions related to grading tests.
    - `storage.py`: Functions for handling file storage.
- `requirements.txt`: Lists dependencies required for the backend application.

### Frontend
- `package.json`: Configuration file for npm, listing dependencies and scripts.
- **public**: Contains static files.
  - `index.html`: Main HTML file for the React application.
- **src**: Contains the source code for the React application.
  - `index.jsx`: Entry point of the React application.
  - `App.jsx`: Main App component.
  - **components**: Contains reusable components.
    - `TestList.jsx`: Displays a list of available tests.
    - `TestRunner.jsx`: Handles the execution of a test.
    - `Question.jsx`: Displays an individual question in a test.
  - **pages**: Contains page components.
    - `Dashboard.jsx`: Displays user statistics and available tests.
    - `TestPage.jsx`: Displays the test interface.
  - **services**: Contains API call functions.
    - `api.js`: Functions for making API calls to the backend.

## Getting Started

### Prerequisites
- Python 3.x
- Node.js and npm

### Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd mock-test-platform
   ```

2. Set up the backend:
   - Navigate to the `backend` directory.
   - Install the required Python packages:
     ```
     pip install -r requirements.txt
     ```

3. Set up the frontend:
   - Navigate to the `frontend` directory.
   - Install the required npm packages:
     ```
     npm install
     ```

### Running the Application

1. Start the backend server:
   ```
   cd backend
   uvicorn app.main:app --reload
   ```

2. Start the frontend development server:
   ```
   cd frontend
   npm start
   ```

### Usage
- Access the frontend application at `http://localhost:3000`.
- The backend API will be available at `http://localhost:8000`.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License
This project is licensed under the MIT License.